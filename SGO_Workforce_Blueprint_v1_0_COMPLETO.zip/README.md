# SGO Workforce Blueprint v1.0

Pacote oficial de concepção e treinamento de agentes para o **SGO Workforce**, plataforma de gestão de jornada, apropriação automática de HH, falhas, telemetria de campo e capacidade operacional.

## Como usar
1. Leia `CLAUDE.md` na raiz.
2. Leia `docs/00_INDICE.md` e os documentos na ordem indicada.
3. Antes de codificar, confirme o alvo da sessão e a fase do roadmap.
4. Use a branch `dev` para funcionalidades de captura, sincronização, GPS e banco.
5. Faça entregas pequenas, testáveis e reversíveis.

## Conteúdo
- visão de produto e contexto do ecossistema SGO;
- arquitetura offline first;
- motor de eventos e HH;
- modelo de pulsos GPS;
- atendimento estruturado de falhas;
- catálogo derivado do RASF;
- dashboards ECharts, mapa e exportações;
- modelo de dados, SQL inicial, backlog e critérios de aceite;
- instruções para Claude Code, GitHub Copilot, Copilot Studio e VS Code.

## Status
Blueprint de concepção. Não contém ainda o código de produção do aplicativo.
